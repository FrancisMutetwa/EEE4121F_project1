function [best_alternative, topsis_score] = topsis(network_data, weights, criteria_type)
    % Normalize the network data
    normalized_data = normalize_matrix(network_data);

    % Calculate weighted normalized decision matrix
    weighted_normalized_data = bsxfun(@times, normalized_data, weights);

    % Determine the ideal and anti-ideal solutions
    if strcmp(criteria_type, 'benefit')
        ideal_solution = max(weighted_normalized_data, [], 1);
        anti_ideal_solution = min(weighted_normalized_data, [], 1);
    elseif strcmp(criteria_type, 'cost')
        ideal_solution = min(weighted_normalized_data, [], 1);
        anti_ideal_solution = max(weighted_normalized_data, [], 1);
    else
        error('Invalid criteria type. Use "benefit" or "cost".');
    end

    % Calculate the distance from each alternative to the ideal and anti-ideal solutions
    distance_to_ideal = sqrt(sum((weighted_normalized_data - ideal_solution).^2, 2));
    distance_to_anti_ideal = sqrt(sum((weighted_normalized_data - anti_ideal_solution).^2, 2));

    % Calculate the TOPSIS score
    topsis_score = distance_to_anti_ideal ./ (distance_to_ideal + distance_to_anti_ideal);

    % Find the best alternative
    [~, best_index] = max(topsis_score);
    best_alternative = network_data(best_index, :);
end