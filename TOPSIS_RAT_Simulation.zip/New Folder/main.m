%Francis Mutetwa
%Student No: MTTFRA005
%Date: 21/03/2024
%Revised: 22/03/2024
%The following program simulates TOPSIS RAT selection. It does this by first 
%prompting the user for the number of users in a particular
%heterogenous network
%The heterogeneous network is already set to different RATs with certain
%criteria such as Available Bandwidth, Cost per Byte and Packet Delay.


%Prompt user for the number of users in a heterogenous network.
X = input('Enter the number of users in Network: ');

% Define network data (same for each user)
RAT_1 = [60,0.5,60]; %4G 
RAT_2 = [15,0.15,100]; % Wi-Fi
RAT_3 = [2,0.6,20]; % 3G
network_data = [RAT_1; RAT_2; RAT_3]; %Decision Matrix

% Initialize cell array to hold user_data
user_data = cell(X, 1);

% Generate random weights and populate user_data
for i = 1:X
    % Generate random weights
    weights = randi([1, 10], 1, size(network_data, 2)); % Random weights for each criterion
    criteria_types = {'benefit', 'cost', 'cost'}; % Adjust as needed
    

    %Task 7: Evaluating the effect of users' weights on the 1st criterion
    %weights(1) = weights(i) * 0; % 1st criterion when made less important
    %weights(1) = weights(1) * 0.5; % 1st criterion when made mid important
    %weights(1) = weights(1) * 0.9; % First Criterion when made very important


    %Task 8: Evaluating the effect of users' weights on the 2nd criterion
    %weights(2) = weights(2) * 0.1; % 2nd Criterion when made less important
    %weights(2) = weights(2) * 0.5; % 2nd Criterion when made mid important
    %weights(2) = weights(2) * 0.9; % 2nd Criterion when made very important


    %Task9: Evaluating the effect of users' weights on the 3rd criterion
    %weights(3) = weights(3) * 0.1; % 3rd criterion when made less important
    %weights(3) = weights(3) * 0.5; % 3rd Criterion when made mid important
    %weights(3) = weights(3) * 0.9; % 3rd criterion when made very important



    % Generate user_data for the current user
    user_data{i} = struct('criteria', {'Available Bandwidth', 'Cost per Byte', 'Packet Delay'}, ...
                          'weights', weights, ...
                          'network_data', network_data, ...
                          'criteria_type', criteria_types); % 
    
    % Display user data for verification
   %disp(['User ', num2str(i), ' data:']);
   %disp(user_data{i});
    %disp(' ');
end


% Call multi_user_topsis function
results = multi_user_topsis(user_data);


% Display or use the results as needed
rat1_4g = 0;
rat2_wifi=0;
rat3_3g=0;
for i = 1:X
    if(results{i,1}==RAT_1)
        rat1_4g=rat1_4g+1;
    elseif((results{i,1}==RAT_2))
        rat2_wifi=rat2_wifi+1;
    else
        rat3_3g=rat3_3g+1;
    end
end


% Define your variables and their values
variables = {'4G', 'Wi-Fi', '3G'};
values = [rat1_4g, rat2_wifi, rat3_3g];  % Example values for each variable
% Create a bar graph
bar(values);
% Customize the appearance
xlabel('RAT');
ylabel('Amount of Users');
title('When random user weights are assigned to each user');
set(gca, 'xticklabel', variables);  % Set x-axis labels
% Show the plot
grid on;


























%numel(results)


% Display or use the results as needed
%for i = 1:X
%    disp(['User ', num2str(i)]);
%    disp('Best Alternative:');
%    disp(results{i, 1});
%    disp('TOPSIS Scores:');
%    disp(results{i, 2});
%end
