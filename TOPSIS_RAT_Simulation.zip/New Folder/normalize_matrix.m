function normalized_matrix = normalize_matrix(matrix)
    % Compute the sum of squares of each column
    column_sums = sum(matrix.^2, 1);

    % Take the square root of the sum of squares of each column
    column_root = sqrt(column_sums);

    % Divide each element of the matrix by the square root of the sum of squares of its column
    normalized_matrix = matrix ./ column_root;
end

