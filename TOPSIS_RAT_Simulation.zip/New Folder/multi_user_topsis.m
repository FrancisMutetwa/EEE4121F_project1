function results = multi_user_topsis(user_data)
    num_users = numel(user_data);
    results = cell(num_users, 2);

    for i = 1:num_users
        criteria = user_data{i}.criteria;
        weights = user_data{i}.weights;
        network_data = user_data{i}.network_data;
        criteria_type = user_data{i}.criteria_type;

        [best_alternative, topsis_score] = topsis(network_data, weights, criteria_type);

        results{i, 1} = best_alternative;
        results{i, 2} = topsis_score;
       
    end    
end



